package com.amitit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogbackApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(LogbackApiApplication.class, args);
	}

}
