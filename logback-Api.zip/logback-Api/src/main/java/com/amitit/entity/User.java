package com.amitit.entity;

public class User {
	private Integer Id;
	private String Name;
	private String city;
	
	/**
	 * @param id
	 * @param name
	 * @param city
	 */
	public User(Integer id, String name, String city) {
		super();
		Id = id;
		Name = name;
		this.city = city;
	}
	
	public User() {
	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return Id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		Id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return Name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		Name = name;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "User [Id=" + Id + ", Name=" + Name + ", city=" + city + "]";
	}
	
	
	
	
	
	

}
