package com.amitit.controller;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.amitit.entity.User;

@RestController
public class HelloController {
	
	private Logger logger=LoggerFactory.getLogger(HelloController.class);
	
	@GetMapping("/hello")
	public String say() {
		
		String msg="Welcome to Home!!..";
		logger.debug(msg);
		logger.info("Successfull!!");
		
		return msg;
	}

	@PostMapping("/user")
	public ResponseEntity<?> addUserInfromation(@RequestBody User user){
		logger.debug("add user request");
		logger.info("user : {}",user);
		logger.info("messaee");
		return ResponseEntity.ok("Done");
		
	}
	@PostMapping("/File")
	public ResponseEntity<?> addUserInfromationFile(@RequestParam("file")MultipartFile file,
			                                        @RequestParam("userData")String userData){
		logger.info("add user request");
		logger.info("file infromation : {}",file.getOriginalFilename());
		logger.info("User : {}",userData);
		logger.info("file messaee");
		return ResponseEntity.ok("file Done");
		
	}
}
