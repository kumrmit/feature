package com.amitit.entity;
import org.apache.commons.lang3.StringUtils;


public final class ExceptionHandling {
	 public String convertIntoUpperCase(String input) {
	        if (StringUtils.isEmpty(input)) {
	            throw new IllegalArgumentException("Empty value is passed.");
	        }
	        return input.toUpperCase();
	    }
	}


