package com.amitit;

import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class ExceptionHandlingTest {
	
	@Mock
	private ExceptionHandling exceptionHandling;

}
